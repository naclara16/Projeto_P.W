
let jsonFile; 

//vinculação do botao do html e criação do listener para o clique
const botaoExibir= document.getElementById('botaoExibir')
const botaoDownload= document.getElementById('botaoDownload')
botaoExibir.addEventListener('click',exibirAlunos)
botaoDownload.addEventListener('click',download)

const bd = `{
    "alunos": [
        {
            "nome": "Dustin Hender",
            "rgm": 501,
            "avaliacaoParcial": 3,
            "exercicios": 1,
            "avaliacaoRegimental": 4,
            "img": "./images/dustin.jpg"
        },
        {
            "nome": "Jane Hopper",
            "rgm": 666,
            "avaliacaoParcial": 2,
            "exercicios": 1,
            "avaliacaoRegimental": 3,
            "img": "./images/jane.jpg"
        },
        {
            "nome": "Lucas Sinclair",
            "rgm": 342,
            "avaliacaoParcial": 1,
            "exercicios": 1,
            "avaliacaoRegimental": 2,
            "img": "./images/lucas.jpg"
        },
        {
            "nome": "Max Mayfield",
            "rgm": 671,
            "avaliacaoParcial": 2,
            "exercicios": 1,
            "avaliacaoRegimental": 2,
            "img": "./images/max.jpg"
        },
        {
            "nome": "Mike Wheeler",
            "rgm": 710,
            "avaliacaoParcial": 1,
            "exercicios": 0,
            "avaliacaoRegimental": 0,
            "img": "./images/mike.jpg"
        },
        {
            "nome": "Will Byers",
            "rgm": 413,
            "avaliacaoParcial": 1,
            "exercicios": 1,
            "avaliacaoRegimental": 4,
            "img": "./images/will.jpg"
        },
        {
            "nome": "Steve Silva",
            "rgm": 220,
            "avaliacaoParcial": 1,
            "exercicios": 1,
            "avaliacaoRegimental": 1,
            "img": "./images/steve.jpg"
        },
        {
            "nome": "Nancy Wheeler",
            "rgm": 222,
            "avaliacaoParcial": 1,
            "exercicios": 0,
            "avaliacaoRegimental": 3,
            "img": "./images/nancy.jpg"
        },
        {
            "nome": "Robin Hawke",
            "rgm": 133,
            "avaliacaoParcial": 2,
            "exercicios": 1,
            "avaliacaoRegimental": 5,
            "img": "./images/robin.jpg"
        },
        {
            "nome": "Billy Hargrove",
            "rgm": 801,
            "avaliacaoParcial": 1,
            "exercicios": 1,
            "avaliacaoRegimental": 0,
            "img": "./images/billy.jpg"
        },
        {
            "nome": "Jonathan ",
            "rgm": 734,
            "avaliacaoParcial": 0,
            "exercicios": 0,
            "avaliacaoRegimental": 1,
            "img": "./images/jonathan.jpg"
        },
        {
            "nome": "Eddie Munson",
            "rgm": 972,
            "avaliacaoParcial": 0,
            "exercicios": 1,
            "avaliacaoRegimental": 3,
            "img": "./images/eddie.jpg"
        },
        {
            "nome": "Erica Sinclair",
            "rgm": 778,
            "avaliacaoParcial": 3,
            "exercicios": 1,
            "avaliacaoRegimental": 5,
            "img": "./images/erica.jpg"
        },
        {
            "nome": "Chrissy ",
            "rgm": 420,
            "avaliacaoParcial": 2,
            "exercicios": 0,
            "avaliacaoRegimental": 3,
            "img": "./images/chrissy.jpg"
        },
        {
            "nome": "Vickie",
            "rgm": 242,
            "avaliacaoParcial": 2,
            "exercicios": 1,
            "avaliacaoRegimental": 1,
            "img": "./images/vickie.jpg"
        },
        {
            "nome": "Barb Holland",
            "rgm": 856,
            "avaliacaoParcial": 2,
            "exercicios": 1,
            "avaliacaoRegimental": 2,
            "img": "./images/barb.jpg"
        },
        {
            "nome": "Suzie",
            "rgm": 941,
            "avaliacaoParcial": 3,
            "exercicios": 1,
            "avaliacaoRegimental": 5,
            "img": "./images/suzie.jpg"
        },
        {
            "nome": "Argyle",
            "rgm": 619,
            "avaliacaoParcial": 0,
            "exercicios": 1,
            "avaliacaoRegimental": 0,
            "img": "./images/argyle.jpg"
        },
        {
            "nome": "Éden",
            "rgm": 777,
            "avaliacaoParcial": 2,
            "exercicios": 1,
            "avaliacaoRegimental": 4,
            "img": "./images/eden.jpg"
        },
        {
            "nome": "Henry Creel",
            "rgm": 588,
            "avaliacaoParcial": 3,
            "exercicios": 1,
            "avaliacaoRegimental": 4,
            "img": "./images/vecna.jpg"
        },
        {
            "nome": "Kali Prasad",
            "rgm": 311,
            "avaliacaoParcial": 3,
            "exercicios": 1,
            "avaliacaoRegimental": 5,
            "img": "./images/kali.jpg"
        },
        {
            "nome": "Fred Benson",
            "rgm": 155,
            "avaliacaoParcial": 3,
            "exercicios": 1,
            "avaliacaoRegimental": 5,
            "img": "./images/fred.jpg"
        },
        {
            "nome": "Jason Carver",
            "rgm": 555,
            "avaliacaoParcial": 0,
            "exercicios": 0,
            "avaliacaoRegimental": 0,
            "img": "./images/jason.jpg"
        },
        {
            "nome": "Angela",
            "rgm": 190,
            "avaliacaoParcial": 0,
            "exercicios": 0,
            "avaliacaoRegimental": 0,
            "img": "./images/angela.jpg"
        },
        {
            "nome": "Troy Walsh",
            "rgm": 888,
            "avaliacaoParcial": 0,
            "exercicios": 1,
            "avaliacaoRegimental": 4,
            "img": "./images/troy.jpg"
        }

    ]
}`

function exibirAlunos() {
    const objs = JSON.parse(bd)



    let resultado = document.getElementById("resultado")

    objs.alunos.forEach(element => {
        console.log(element)
        
        let media = element.avaliacaoParcial + element.exercicios + element.avaliacaoRegimental
        let status
            if(media >= 6){
                status = "Aprovado"
            } else if(media >= 2 && media <= 6){
                status = "Avaliação Final"
            } else if(media < 2){
                status = "Reprovado"
            }
        element.media = media;
        element.status = status;
        
        resultado.innerHTML +=
        `<div class="container">
        <img src="${element.img}" alt="1"/>
        <p><b>Nome: </b> ${element.nome}</p>
        <p><b>RGM: </b> ${element.rgm}</p>
        <p><b>Av. Parcial: </b> ${element.avaliacaoParcial}</p>
        <p><b>Exercícios: </b> ${element.exercicios}</p>
        <p><b>Av. Regimental: </b> ${element.avaliacaoRegimental}</p>
        <p><b>Média: </b> ${media}</p>
        <p><b>Status: </b> ${status}</p>
        </div>`
    });

    const file = 'alunos.json';
    const json = JSON.stringify(objs,null,4);
    jsonFile = json;
}
// gera o arquivo json para download
function download() {
    if( jsonFile == undefined ){
        exibirAlunos();
    }
    let a = document.createElement("a");
    let file = new Blob([jsonFile], {type: 'application/json'});
    a.href = URL.createObjectURL(file);
    a.download = 'alunos.json';
    a.click();
}