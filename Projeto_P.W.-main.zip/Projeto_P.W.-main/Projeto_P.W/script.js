//importção do arquivo que contem a constante com a string do json
import bd from './bd.js'
let jsonFile;

//vinculação do botao do html e criação do listener para o clique
const botaoExibir= document.getElementById('botaoExibir')
const botaoDownload= document.getElementById('botaoDownload')
botaoExibir.addEventListener('click',exibirAlunos)
botaoDownload.addEventListener('click',download)

//realiza os calculos e adiciona o status para exibir no componente html
function exibirAlunos() {
    const objs = JSON.parse(bd)

    let resultado = document.getElementById("resultado")

    objs.alunos.forEach(element => {
        console.log(element)
        
        let media = element.avaliacaoParcial + element.exercicios + element.avaliacaoRegimental
        let status
            if(media >= 6){
                status = "Aprovado"
            } else if(media >= 2 && media <= 6){
                status = "Avaliação Final"
            } else if(media < 2){
                status = "Reprovado"
            }
       element.media = media;
       element.status = status;

        resultado.innerHTML +=
        `<div class="container">
        <img src="${element.img}" alt="1"/>
        <p><b>Nome: </b> ${element.nome}</p>
        <p><b>RGM: </b> ${element.rgm}</p>
        <p><b>Av. Parcial: </b> ${element.avaliacaoParcial}</p>
        <p><b>Exercícios: </b> ${element.exercicios}</p>
        <p><b>Av. Regimental: </b> ${element.avaliacaoRegimental}</p>
        <p><b>Média: </b> ${element.media}</p>
        <p><b>Status: </b> ${element.status}</p>
        </div>`
    });
    const file = 'alunos.json';
    const json = JSON.stringify(objs,null,4);
    jsonFile = json;
    
} 

// gera o arquivo json para download
function download() {
    if( jsonFile == undefined ){
        exibirAlunos();
    }
    let a = document.createElement("a");
    let file = new Blob([jsonFile], {type: 'application/json'});
    a.href = URL.createObjectURL(file);
    a.download = 'alunos.json';
    a.click();
}